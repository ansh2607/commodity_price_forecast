d3.csv('C:\Users\goyal\Downloads\Farmer App - Weather data from MetSwift-20210603T125907Z-001\Farmer App - Weather data from MetSwift\Not For Profit - Punjab\Station Data\Blended\IN0008B.csv')
  .then(makeChart);

function makeChart(weather)